return {
  "https://atmdl.leiting.com/g-bits",
}